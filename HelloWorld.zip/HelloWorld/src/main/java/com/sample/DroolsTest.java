package com.sample;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;

import com.sample.model.Breed;
import com.sample.model.Disease;
import com.sample.model.DiseaseCategory;
import com.sample.model.Ingredient;
import com.sample.model.Owner;
import com.sample.model.Patient;
import com.sample.model.Symptom;
import com.sample.model.Therapy;
import com.sample.model.Vet;
import com.sample.model.Medicine;

/**
 * This is a sample class to launch a rule.
 */
public class DroolsTest {

    public static final void main(String[] args) {
        try {
            // load up the knowledge base
	        KieServices ks = KieServices.Factory.get();
    	    KieContainer kContainer = ks.getKieClasspathContainer();
        	KieSession kSession = kContainer.newKieSession("ksession-rules");

            // go !
            Message message = new Message();
            message.setMessage("Hello World");
            message.setStatus(Message.HELLO);
            kSession.insert(message);
            init(kSession);
            kSession.fireAllRules();
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    public static void init(KieSession kSession) {
    	Vet v=new Vet((long) 0, "v1", "v", "v", "v");
    	
    	Owner o=new Owner((long) 0, "o", "o", "0");
    	
    	Patient p1=new Patient((long) 0, "p1", "p1", new Date(), Breed.DOBERMAN, o, new ArrayList<Medicine>(), new ArrayList<Ingredient>());
    	
    	ArrayList<Symptom> s1=new ArrayList<>();
    	s1.add(Symptom.DIARRHEA);
    	s1.add(Symptom.INCREASED_HEART_RATE);
    	ArrayList<Symptom> s2=new ArrayList<>();
    	s2.add(Symptom.DIARRHEA);
    	s2.add(Symptom.VOMITING);
    	s2.add(Symptom.INCREASED_THIRST);
    	ArrayList<Therapy> t=new ArrayList<>();
    	Disease d1=new Disease((long) 0, "d1", DiseaseCategory.CANCER, new ArrayList<Symptom>(), s1, t);
    	Disease d2=new Disease((long) 1, "d2", DiseaseCategory.CANCER, new ArrayList<Symptom>(), s2, t);
    	
    	Symptom sy1=Symptom.VOMITING;
    	
    	kSession.insert(d1);
    	kSession.insert(d2);
    	kSession.insert(sy1);
    	
    }
    
    public static class Message {

        public static final int HELLO = 0;
        public static final int GOODBYE = 1;

        private String message;

        private int status;

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public int getStatus() {
            return this.status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

    }

}
