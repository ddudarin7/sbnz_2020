package com.sample.model;

import java.util.Date;
import java.util.List;


public class Patient {
	
    private Long id;

    private String name;

    private String recordNumber;
    
    private Date dateOfBirth;
    
    private Breed breed;

    private Owner owner;

    private List<Medicine> medicineAllergies;

    private List<Ingredient> ingredientAllergies;
    
    public Patient() {}

	public Patient(Long id, String name, String recordNumber, Date dateOfBirth, Breed breed, Owner owner,
			List<Medicine> medicineAllergies, List<Ingredient> ingredientAllergies) {
		super();
		this.id = id;
		this.name = name;
		this.recordNumber = recordNumber;
		this.dateOfBirth = dateOfBirth;
		this.breed = breed;
		this.owner = owner;
		this.medicineAllergies = medicineAllergies;
		this.ingredientAllergies = ingredientAllergies;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRecordNumber() {
		return recordNumber;
	}

	public void setRecordNumber(String recordNumber) {
		this.recordNumber = recordNumber;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Breed getBreed() {
		return breed;
	}

	public void setBreed(Breed breed) {
		this.breed = breed;
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	public List<Medicine> getMedicineAllergies() {
		return medicineAllergies;
	}

	public void setMedicineAllergies(List<Medicine> medicineAllergies) {
		this.medicineAllergies = medicineAllergies;
	}

	public List<Ingredient> getIngredientAllergies() {
		return ingredientAllergies;
	}

	public void setIngredientAllergies(List<Ingredient> ingredientAllergies) {
		this.ingredientAllergies = ingredientAllergies;
	}

}
