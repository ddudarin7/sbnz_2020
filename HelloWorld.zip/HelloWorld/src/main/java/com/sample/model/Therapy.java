package com.sample.model;

import java.util.List;

public class Therapy {
	
    private Long id;
    
    private List<Medicine> medicines;
	
    private String description;
    
    public Therapy() {}

	public Therapy(Long id, List<Medicine> medicines, String description) {
		super();
		this.id = id;
		this.medicines = medicines;
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Medicine> getMedicines() {
		return medicines;
	}

	public void setMedicines(List<Medicine> medicines) {
		this.medicines = medicines;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
