package com.sample.model;

public enum Symptom {
    VOMITING,
    DIARRHEA,
    INCREASED_THIRST,
    INCREASED_HEART_RATE
	
}
