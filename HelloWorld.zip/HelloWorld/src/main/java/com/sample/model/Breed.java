package com.sample.model;

public enum Breed {
	MIXEDBREED,
	HUSKY,
	DOBERMAN,
	PUG,
	LABRADOR,
	ROTTWEILER,
	PITBULL;
}
