package com.sample.model;

import java.util.List;


public class Disease {
	
	private Long id;

    private String name;

    private DiseaseCategory diseaseCategory;

    private List<Symptom> specificSymptoms;

    private List<Symptom> nonSpecificSymptoms;

    private List<Therapy> therapies;
    
    public Disease() {}

	public Disease(Long id, String name, DiseaseCategory diseaseCategory, List<Symptom> specificSymptoms,
			List<Symptom> nonSpecificSymptoms, List<Therapy> therapies) {
		super();
		this.id = id;
		this.name = name;
		this.diseaseCategory = diseaseCategory;
		this.specificSymptoms = specificSymptoms;
		this.nonSpecificSymptoms = nonSpecificSymptoms;
		this.therapies = therapies;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DiseaseCategory getDiseaseCategory() {
		return diseaseCategory;
	}

	public void setDiseaseCategory(DiseaseCategory diseaseCategory) {
		this.diseaseCategory = diseaseCategory;
	}

	public List<Symptom> getSpecificSymptoms() {
		return specificSymptoms;
	}

	public void setSpecificSymptoms(List<Symptom> specificSymptoms) {
		this.specificSymptoms = specificSymptoms;
	}

	public List<Symptom> getNonSpecificSymptoms() {
		return nonSpecificSymptoms;
	}

	public void setNonSpecificSymptoms(List<Symptom> nonSpecificSymptoms) {
		this.nonSpecificSymptoms = nonSpecificSymptoms;
	}

	public List<Therapy> getTherapies() {
		return therapies;
	}

	public void setTherapies(List<Therapy> therapies) {
		this.therapies = therapies;
	}

}
