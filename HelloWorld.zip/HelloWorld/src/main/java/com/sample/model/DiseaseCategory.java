package com.sample.model;

public enum DiseaseCategory {
	INFECTIOUS,
	POISONING,
	CANCER,
	CARDIOVASCULAR,
	NEUROLOGIC,
	EYEDISEASE,
	ENDOCRINE,
	URINAR,
	OTHER,
	BEHAVIORAL,
	ENVIRONMENTAL
	
	

}
